#!/bin/bash
DIR_ORIGEN="/var"
DIR_DESTINO="/backup_dir"
SIZE_SPLITEO="500M"

TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
TEMP_TAR_GZ="$DIR_DESTINO/var_${TIMESTAMP}.tar.gz"
SPLIT_PREFIX="$DIR_DESTIN/var_${TIMESTAMP}_part"

echo "Iniciando backup y spliteo de $DIR_ORIGEN..."

#Me aseguro que el dir "/backup_dir" exista
mkdir -p "$DIR_DESTINO"

#Creo el archivo tar.gz de /var
tar -czvf "$TEMP_TAR_GZ" "$DIR_ORIGEN"

if [ $? -ne 0 ];
then
	echo "Error: Falló la creación del archivo tar.gz de $DIR_ORIGEN."
	exit 1
fi
echo "Archivo tar.gz creado exitosamente: $TEMP_TAR_GZ"

# Realizo el split del archivo tar.gz
split -b "$SIZE_SPLITEO" -d -a 2 "$TEMP_TAR_GZ" "$SPLIT_PREFIX"

if [ $? -ne 0];
then
	echo "ERROR: Falló el split del archivo $TEMP_TAR_GZ. Los trozos pueden estar incompletos."
	exit 1
fi
echo "Archivo dividido exitosamente: $TEMP_TAR_GZ en: ${SPLIT_PREFIX}00, ${SPLIT_PREFIX}01, etc..."

#Debería de eliminar a TEMP_TAR_GZ ??

echo "Proceso de backuo y división de $DIR_ORIGEN completo."

